package com.example.game

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var currentScreen by remember { mutableStateOf("menu") }
            var showAboutDialog by remember { mutableStateOf(false) }

            when (currentScreen) {
                "menu" -> MainMenuScreen(
                    onStartGame = { currentScreen = "game" },
                    onShowAbout = { showAboutDialog = true }
                )
                "game" -> DiceGameScreen()
            }

            if (showAboutDialog) {
                AboutDialog(onDismiss = { showAboutDialog = false })
            }
        }
    }
}


@Composable
fun MainMenuScreen(onStartGame: () -> Unit, onShowAbout: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Welcome to the Dice Game!", fontSize = 24.sp, color = Color.Black)
        Spacer(modifier = Modifier.height(20.dp))
        Button(onClick = onStartGame) {
            Text("Start Game", fontSize = 18.sp)
        }
        Spacer(modifier = Modifier.height(12.dp))
        Button(onClick = onShowAbout) {
            Text("About", fontSize = 18.sp)
        }
    }
}

@Composable
fun DiceGameScreen() {
    var humanDice by remember { mutableStateOf(List(5) { Random.nextInt(1, 7) }) }
    var computerDice by remember { mutableStateOf(List(5) { Random.nextInt(1, 7) }) }
    var humanScore by remember { mutableStateOf(0) }
    var computerScore by remember { mutableStateOf(0) }
    var humanRerolls by remember { mutableStateOf(0) }
    var selectedDice = remember { mutableStateListOf(false, false, false, false, false) }
    var gameOver by remember { mutableStateOf(false) }
    var targetScore by remember { mutableStateOf(TextFieldValue("101")) }

    Column(
        Modifier.fillMaxSize().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly
    ) {
        Text("H: $humanScore / C: $computerScore", fontSize = 18.sp, color = Color.Black)

        OutlinedTextField(
            value = targetScore,
            onValueChange = { newValue ->
                if (newValue.text.all { it.isDigit() }) targetScore = newValue
            },
            label = { Text("Enter Target Score") },
            keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth().padding(8.dp)
        )

        DiceRow(humanDice, "Your Dice", selectedDice)
        DiceRow(computerDice, "Computer Dice", null)

        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Button(
                onClick = {
                    if (humanRerolls < 2 && !gameOver) {
                        humanDice = humanDice.mapIndexed { index, value ->
                            if (!selectedDice[index]) Random.nextInt(1, 7) else value
                        }
                        humanRerolls++
                    }
                },
                enabled = !gameOver
            ) { Text("Throw") }

            Button(
                onClick = {
                    val result = performScoring(
                        humanDice, computerDice, humanScore, computerScore, targetScore.text.toIntOrNull() ?: 101
                    )
                    humanScore = result.first
                    computerScore = result.second
                    gameOver = result.third
                },
                enabled = !gameOver
            ) { Text("Score") }
        }

        if (gameOver) {
            Button(
                onClick = {
                    humanDice = List(5) { Random.nextInt(1, 7) }
                    computerDice = List(5) { Random.nextInt(1, 7) }
                    humanScore = 0
                    computerScore = 0
                    humanRerolls = 0
                    selectedDice = mutableStateListOf(false, false, false, false, false)
                    gameOver = false
                }
            ) { Text("Restart Game") }
        }
    }
}

@Composable
fun DiceRow(diceValues: List<Int>, label: String, selectedDice: MutableList<Boolean>?) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, fontSize = 18.sp, color = Color.Black)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            diceValues.forEachIndexed { index, value ->
                Card(
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.size(60.dp).padding(4.dp)
                        .clickable { selectedDice?.set(index, !selectedDice[index]) }
                ) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                        Image(painter = painterResource(id = getDiceImage(value)), contentDescription = "Dice $value")
                    }
                }
            }
        }
    }
}

fun getDiceImage(value: Int): Int {
    return when (value) {
        1 -> R.drawable.dice1
        2 -> R.drawable.dice2
        3 -> R.drawable.dice3
        4 -> R.drawable.dice4
        5 -> R.drawable.dice5
        6 -> R.drawable.dice6
        else -> R.drawable.dice1
    }
}

fun performScoring(
    humanDice: List<Int>,
    computerDice: List<Int>,
    humanScore: Int,
    computerScore: Int,
    targetScore: Int
): Triple<Int, Int, Boolean> {
    val newHumanScore = humanScore + humanDice.sum()
    val newComputerScore = computerScore + computerDice.sum()
    val gameOver = newHumanScore >= targetScore || newComputerScore >= targetScore
    return Triple(newHumanScore, newComputerScore, gameOver)
}

@Composable
fun AboutDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("About") },
        text = { Text("Author: Onyinye Blessing Anago\n(Student ID: 2037459)\nI confirm that I understand what plagiarism is and have read and\nunderstood the section on Assessment Offences in the Essential\nInformation for Students. The work that I have submitted is\nentirely my own. Any work from other authors is duly referenced\nand acknowledged.") },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}
